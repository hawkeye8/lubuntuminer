./ethdcrminer64 -epool us-east.ethash-hub.miningpoolhub.com:17020 -ewal jtoma.1060rig -eworker jtoma.1060rig -esm 2 -epsw x -allcoins 1
