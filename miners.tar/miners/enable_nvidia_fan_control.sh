#!/bin/bash
sudo nvidia-xconfig --enable-all-gpus
sudo nvidia-xconfig --cool-bits=12
